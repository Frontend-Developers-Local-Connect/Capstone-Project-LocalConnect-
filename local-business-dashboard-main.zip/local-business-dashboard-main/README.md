# LocalBusinessDashboard
This part of the project contains the welcome page for the local business dashboard as well as the account creation/login page.
